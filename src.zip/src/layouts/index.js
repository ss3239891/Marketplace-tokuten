import DefaultLayout from "./Default";

export { DefaultLayout };
